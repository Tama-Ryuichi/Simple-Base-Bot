global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['62']
global.gambar = "https://files.catbox.moe/zhbsht.jpg"